// =====================================================  draw_grid ====
function draw_grid( rctx, rminor, rmajor, rstroke, rfill  ) //draws an X-Y grid over a canvas
{
    rctx.save( );
    rctx.strokeStyle = rstroke;//set line color
    rctx.fillStyle = rfill;//color of numbers
    let width = rctx.canvas.width;//width of rctx
    let height = rctx.canvas.height;//height of rctx
    for ( var ix = 0; ix < width; ix += rminor )//loop from 0 to width 
        //incrementing by number of pixels in width of one box
        //every rmajor pixels line is bolder than rest of lines and contains X coordinate
    {
        rctx.beginPath( );
        rctx.moveTo( ix, 0 );
        rctx.lineTo( ix, height );
        rctx.lineWidth = ( ix % rmajor == 0 ) ? 0.5 : 0.25;
        rctx.stroke( );
        if (ix % rmajor == 0)
        {
            rctx.fillText(ix/10, ix, 10);
        }
    }
    for (var iy = 0; iy < height; iy += rminor)//loop from 0 to height 
        //incrementing by number of pixels in height of one box
        //every rmajor pixels line is bolder than rest of lines and contains Y coordinate
    {
        rctx.beginPath( );
        rctx.moveTo( 0, iy );
        rctx.lineTo( width, iy );
        rctx.lineWidth = ( iy % rmajor == 0 ) ? 0.5 : 0.25;
        rctx.stroke( );
        if (iy % rmajor == 0)
        {
            rctx.fillText(iy/10, 0, iy + 10);
        }
    }
    rctx.restore( );
}

//struct for coordinates
function coordinates(x_c, y_c, direction)
{
    this.x_c = x_c;//X coordinate
    this.y_c = y_c;//Y coordinate
    this.direction = direction;//0-N, 1-E, 2-S, 3-E
}

//change color
function change_color(s, coordinates)
{
    context.fillStyle = s;//color we change to
    context.fillRect(coordinates.x_c * 10, coordinates.y_c * 10, 10, 10);//filling a 10x10 pixel box at X and Y coordinates
}

//turn right function
function turn_right(my_coordinates)
{
    if (my_coordinates.direction == 0)//facing north
    {
        my_coordinates.x_c++;
        my_coordinates.direction++;//turns east
    }
    else if (my_coordinates.direction == 1)//facing east
    {
        my_coordinates.y_c++;
        my_coordinates.direction++;//turns south
    }
    else if (my_coordinates.direction == 2)//facing south
    {
        my_coordinates.x_c--;
        my_coordinates.direction++;//turns west
    }
    else if (my_coordinates.direction == 3)//facing west
    {
        my_coordinates.y_c--;
        my_coordinates.direction = 0;//turns north
    }
}

function turn_left(my_coordinates)
{
    if (my_coordinates.direction == 0)//facing north
    {
        my_coordinates.x_c--;
        my_coordinates.direction = 3;//turns west
    }
    else if (my_coordinates.direction == 1)//facing east
    {
        my_coordinates.y_c--;
        my_coordinates.direction--;//turns south
    }
    else if (my_coordinates.direction == 2)//facing south
    {
        my_coordinates.x_c++;
        my_coordinates.direction--;//turns east
    }
    else if (my_coordinates.direction == 3)//facing west
    {
        my_coordinates.y_c++;
        my_coordinates.direction--;//turns north
    }
}

//check value in 2-d array to determine color 
//depending on color changes the color on array and in display 
//Moves the ant to right or left
function check_color(ctx, state, my_coordinates)
{
    ctx.save();
    var x = my_coordinates.x_c;//X coordinate
    var y = my_coordinates.y_c;//Y coordinate
    var color = state[x][y];//current color in state table
    
    if (color == 0)//if black
    {
        change_color('red', my_coordinates);//change color to red
        turn_right(my_coordinates);//change coordinates and direction
    }
    else if (color == 1)//if red
    {
        change_color('yellow', my_coordinates);//change color to yellow
        turn_right(my_coordinates);//change coordinates and direction
    }
    else if (color == 2)//if yellow
    {
        change_color('blue', my_coordinates);//change color to blue
        turn_left(my_coordinates);//change coordinates and direction
    }
    else if (color == 3)// if blue
    {
        change_color('black', my_coordinates);//change color to black
        turn_left(my_coordinates);//change coordinates and direction
    }
    color++;//change color to new color
    color = color % 4;//if 4 reset color to 0
    state[x][y] = color;//change state of 2-d array to new color
    ctx.restore();
}

function draw_triangle(rctx, my_coordinates) {//rp1x, rp1y, rp2x, rp2y, rp3x, rp3y
    rctx.save();

    // BL Triangle.
    rctx.beginPath();
    rctx.strokeStyle = "white";//color of line of triangle
    if (0 == my_coordinates.direction)//if facing north
    {
        rp1x = 10 * my_coordinates.x_c + 5;
        rp1y = 10 * my_coordinates.y_c;
        rp2x = 10 * my_coordinates.x_c + 10;
        rp2y = 10 * my_coordinates.y_c + 10;
        rp3x = 10 * my_coordinates.x_c;
        rp3y = 10 * my_coordinates.y_c + 10;
        rctx.moveTo(rp1x, rp1y); //start at top middle of current square
        rctx.lineTo(rp2x, rp2y); //move to bottom right of current square
        rctx.lineTo(rp3x, rp3y); //move to bottom left of curent square
        rctx.closePath();//close triangle
        rctx.stroke();
    }
    else if (1 == my_coordinates.direction)//if facing east
    {
        rp1x = 10 * my_coordinates.x_c + 10;
        rp1y = 10 * my_coordinates.y_c + 5;
        rp2x = 10 * my_coordinates.x_c;
        rp2y = 10 * my_coordinates.y_c + 10;
        rp3x = 10 * my_coordinates.x_c;
        rp3y = 10 * my_coordinates.y_c;
        rctx.moveTo(rp1x, rp1y); 
        rctx.lineTo(rp2x, rp2y); 
        rctx.lineTo(rp3x, rp3y); 
        rctx.closePath();
        rctx.stroke();
    }
    else if (2 == my_coordinates.direction)//if facing south
    {
        rp1x = 10 * my_coordinates.x_c + 5;
        rp1y = 10 * my_coordinates.y_c + 10;
        rp2x = 10 * my_coordinates.x_c;
        rp2y = 10 * my_coordinates.y_c;
        rp3x = 10 * my_coordinates.x_c + 10;
        rp3y = 10 * my_coordinates.y_c;
        rctx.moveTo(rp1x, rp1y);
        rctx.lineTo(rp2x, rp2y);
        rctx.lineTo(rp3x, rp3y);
        rctx.closePath();
        rctx.stroke();
    }
    else if (3 == my_coordinates.direction)//if facing west
    {
        rp1x = 10 * my_coordinates.x_c;
        rp1y = 10 * my_coordinates.y_c + 5;
        rp2x = 10 * my_coordinates.x_c + 10;
        rp2y = 10 * my_coordinates.y_c;
        rp3x = 10 * my_coordinates.x_c + 10;
        rp3y = 10 * my_coordinates.y_c + 10;
        rctx.moveTo(rp1x, rp1y);
        rctx.lineTo(rp2x, rp2y);
        rctx.lineTo(rp3x, rp3y);
        rctx.closePath();
        rctx.stroke();
    }

    rctx.restore();
}