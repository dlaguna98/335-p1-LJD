Team Member: David Laguna
Team Name: LJD
Project Number: 1
Class Number: 335-05
Contents:2 folders, assets and HTML, a README.txt, and BigO.pdf
In assets there is a js file called draw_stuff.js and styles.css
In HTML there is an HTML file called Project_1.html
External requirements: A web browser
Setup and installation: none
Features: Calls a program that displays a Cella Ant 12 
on an HTML webpage. A traingle will define which direction 
the ant is facing after every turn.
Bugs: None

Tested in Google Chrome
==============================================================

How to handle Project_1

1. Main file is Project_1.html, a web page
2. Sibling folder is "assets"
3. Web page links to assets/styles.css
4. Web page has basic title, header, and text
5. After body it loads draw-stuff.js from assets
6. Then runs some Javascript commands

How to run the web page:
7. Drag and drop the Project_1.html file into a web browser